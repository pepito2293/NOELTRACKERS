import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Lock, CheckCircle, XCircle } from 'lucide-react';
import { LanguageProvider, useLanguage } from '../components/LanguageContext';
import LanguageSelector from '../components/LanguageSelector';

function CodeAccessContent() {
  const { t } = useLanguage();
  const [code, setCode] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  // Vérifier si l'utilisateur a déjà un code valide en localStorage
  useEffect(() => {
    const hasAccess = localStorage.getItem('noel_access_granted');
    if (hasAccess === 'true') {
      window.location.href = '/NoelTracker';
    }
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      // Récupérer tous les codes actifs
      const accessCodes = await base44.entities.AccessCode.filter({ is_active: true });
      
      // Vérifier si le code existe
      const validCode = accessCodes.find(ac => ac.code.toUpperCase() === code.trim().toUpperCase());
      
      if (validCode) {
        // Sauvegarder l'accès dans localStorage
        localStorage.setItem('noel_access_granted', 'true');
        
        // Rediriger vers l'application
        window.location.href = '/NoelTracker';
      } else {
        setError(t('invalidCode'));
      }
    } catch (err) {
      setError(t('error'));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-red-50 via-white to-green-50 p-4">
      <div className="absolute top-4 right-4">
        <LanguageSelector />
      </div>
      <Card className="w-full max-w-md shadow-2xl">
        <CardHeader className="text-center space-y-2 pb-6">
          <div className="flex justify-center mb-4">
            <div className="relative">
              <div className="text-6xl">🎄</div>
              <Lock className="absolute -right-1 -bottom-1 w-6 h-6 text-red-600 bg-white rounded-full p-1" />
            </div>
          </div>
          <CardTitle className="text-3xl font-bold text-gray-800">
            {t('welcome')}
          </CardTitle>
          <CardDescription className="text-base">
            {t('enterCode')}
          </CardDescription>
        </CardHeader>
        
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Input
                type="text"
                value={code}
                onChange={(e) => setCode(e.target.value)}
                placeholder={t('enterCodePlaceholder')}
                className="h-12 text-center text-lg font-semibold tracking-wider uppercase"
                required
                autoFocus
              />
              {error && (
                <div className="flex items-center gap-2 text-red-600 text-sm bg-red-50 p-3 rounded-lg">
                  <XCircle className="w-4 h-4" />
                  {error}
                </div>
              )}
            </div>
            
            <Button
              type="submit"
              className="w-full h-12 text-base font-semibold bg-red-600 hover:bg-red-700"
              disabled={loading}
            >
              {loading ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                  {t('verifying')}
                </>
              ) : (
                <>
                  <CheckCircle className="w-5 h-5 mr-2" />
                  {t('access')}
                </>
              )}
            </Button>
          </form>

          <div className="mt-6 pt-6 border-t text-center">
            <p className="text-sm text-gray-600">
              {t('noCode')}
            </p>
            <p className="text-xs text-gray-500 mt-1">
              {t('contactAdmin')}
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export default function CodeAccess() {
  return (
    <LanguageProvider>
      <CodeAccessContent />
    </LanguageProvider>
  );
}