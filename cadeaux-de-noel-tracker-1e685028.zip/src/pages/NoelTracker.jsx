import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Plus, ChevronDown, ChevronUp } from 'lucide-react';
import ChristmasDecoration from '../components/ChristmasDecoration';
import ChristmasWreath from '../components/christmas/ChristmasWreath';
import BudgetSection from '../components/christmas/BudgetSection';
import CategoryChart from '../components/christmas/CategoryChart';
import BudgetComparisonChart from '../components/christmas/BudgetComparisonChart';
import CategoryTable from '../components/christmas/CategoryTable';
import StatsCards from '../components/christmas/StatsCards';
import GiftTable from '../components/christmas/GiftTable';
import AddGiftForm from '../components/christmas/AddGiftForm';
import ThemeSelector, { THEMES } from '../components/christmas/ThemeSelector';
import { LanguageProvider, useLanguage } from '../components/LanguageContext';
import LanguageSelector from '../components/LanguageSelector';

function NoelTrackerContent() {
  const { t } = useLanguage();
  const queryClient = useQueryClient();
  const [daysUntilChristmas, setDaysUntilChristmas] = useState(0);
  const [showAddForm, setShowAddForm] = useState(false);
  const [showStats, setShowStats] = useState(true);
  const [currentTheme, setCurrentTheme] = useState('classic');
  const [christmasDate, setChristmasDate] = useState('2025-12-25');
  const [editingDate, setEditingDate] = useState(false);

  const theme = THEMES[currentTheme];

  // Vérifier l'accès via code
  const [hasAccess, setHasAccess] = useState(false);
  const [checkingAccess, setCheckingAccess] = useState(true);

  useEffect(() => {
    const accessGranted = localStorage.getItem('noel_access_granted');
    if (accessGranted === 'true') {
      setHasAccess(true);
      setCheckingAccess(false);
    } else {
      window.location.href = '/CodeAccess';
    }
  }, []);

  // Fetch gifts (pas de filtre par utilisateur)
  const { data: gifts = [], isLoading: giftsLoading } = useQuery({
    queryKey: ['gifts'],
    queryFn: () => base44.entities.Gift.list('-created_date'),
    initialData: [],
    enabled: hasAccess
  });

  // Fetch budget
  const { data: budgets = [] } = useQuery({
    queryKey: ['budgets'],
    queryFn: () => base44.entities.Budget.list(),
    initialData: [],
    enabled: hasAccess
  });

  const budget = budgets[0];

  // Mutations avec optimistic updates
  const createGiftMutation = useMutation({
    mutationFn: (data) => base44.entities.Gift.create(data),
    onMutate: async (newGift) => {
      await queryClient.cancelQueries({ queryKey: ['gifts'] });
      const previousGifts = queryClient.getQueryData(['gifts']);
      queryClient.setQueryData(['gifts'], (old) => [
        { ...newGift, id: 'temp-' + Date.now(), created_date: new Date().toISOString() },
        ...(old || [])
      ]);
      return { previousGifts };
    },
    onError: (err, newGift, context) => {
      queryClient.setQueryData(['gifts'], context.previousGifts);
    },
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: ['gifts'] });
      setShowAddForm(false);
    }
  });

  const updateGiftMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Gift.update(id, data),
    onMutate: async ({ id, data }) => {
      await queryClient.cancelQueries({ queryKey: ['gifts'] });
      const previousGifts = queryClient.getQueryData(['gifts']);
      queryClient.setQueryData(['gifts'], (old) =>
        old.map((gift) => (gift.id === id ? { ...gift, ...data } : gift))
      );
      return { previousGifts };
    },
    onError: (err, variables, context) => {
      queryClient.setQueryData(['gifts'], context.previousGifts);
    },
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: ['gifts'] });
    }
  });

  const deleteGiftMutation = useMutation({
    mutationFn: (id) => base44.entities.Gift.delete(id),
    onMutate: async (id) => {
      await queryClient.cancelQueries({ queryKey: ['gifts'] });
      const previousGifts = queryClient.getQueryData(['gifts']);
      queryClient.setQueryData(['gifts'], (old) => old.filter((gift) => gift.id !== id));
      return { previousGifts };
    },
    onError: (err, id, context) => {
      queryClient.setQueryData(['gifts'], context.previousGifts);
    },
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: ['gifts'] });
    }
  });

  const updateBudgetMutation = useMutation({
    mutationFn: async (data) => {
      if (budget?.id) {
        return base44.entities.Budget.update(budget.id, data);
      } else {
        return base44.entities.Budget.create(data);
      }
    },
    onMutate: async (newData) => {
      await queryClient.cancelQueries({ queryKey: ['budgets'] });
      const previousBudgets = queryClient.getQueryData(['budgets']);
      if (budget?.id) {
        queryClient.setQueryData(['budgets'], (old) =>
          old.map((b) => (b.id === budget.id ? { ...b, ...newData } : b))
        );
      } else {
        queryClient.setQueryData(['budgets'], (old) => [
          { ...newData, id: 'temp-' + Date.now() },
          ...(old || [])
        ]);
      }
      return { previousBudgets };
    },
    onError: (err, newData, context) => {
      queryClient.setQueryData(['budgets'], context.previousBudgets);
    },
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: ['budgets'] });
    }
  });

  // Calculate days until Christmas
  useEffect(() => {
    const calculateDays = () => {
      const today = new Date();
      const christmas = new Date(christmasDate);
      const diffTime = christmas - today;
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      setDaysUntilChristmas(diffDays);
    };
    calculateDays();
  }, [christmasDate]);

  // Calculate totals
  const totalDepense = gifts.reduce((sum, g) => sum + (g.prix_depense || 0), 0);
  const totalBudgetise = gifts.reduce((sum, g) => sum + (g.prix_budgete || 0), 0);
  const devise = budget?.devise || '€';
  const budgetTotal = budget?.budget_total || 0;

  if (checkingAccess || !hasAccess) {
    return null;
  }

  if (giftsLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-red-50 to-green-50">
        <div className="text-center">
          <div className="text-4xl mb-4">🎄</div>
          <p className="text-xl text-gray-700">{t('loading')}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen relative overflow-hidden" style={{ backgroundColor: theme.background }}>
      <ChristmasDecoration />
      
      <div className="container mx-auto px-4 py-6 pt-14 max-w-[1800px]">
        {/* Header - Centré et harmonieux */}
        <div className="mb-6 space-y-4">
          {/* Logo centré */}
          <div className="flex justify-center">
            <ChristmasWreath />
          </div>

          {/* Infos principales - 3 colonnes équilibrées */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-stretch">
            {/* Date de Noël */}
            <div className="rounded-lg px-5 py-4 shadow-lg" style={{ backgroundColor: theme.primary }}>
              <h2 className="text-white font-bold text-sm text-center mb-2">{t('christmasDate')}</h2>
              {editingDate ? (
                <div className="flex gap-2 items-center justify-center">
                  <Input
                    type="date"
                    value={christmasDate}
                    onChange={(e) => setChristmasDate(e.target.value)}
                    className="h-8 text-sm w-36"
                  />
                  <Button
                    size="sm"
                    onClick={() => setEditingDate(false)}
                    className="h-8 bg-green-600 hover:bg-green-700"
                  >
                    OK
                  </Button>
                </div>
              ) : (
                <div className="flex gap-2 items-center justify-center">
                  <p className="text-white text-lg font-bold">
                    {new Date(christmasDate).toLocaleDateString('fr-FR')}
                  </p>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => setEditingDate(true)}
                    className="h-6 w-6 p-0 text-white hover:bg-white/20"
                  >
                    ✏️
                  </Button>
                </div>
              )}
            </div>

            {/* Compte à rebours */}
            <div className="rounded-lg px-5 py-4 shadow-lg flex items-center justify-center" style={{ backgroundColor: theme.secondary }}>
              <p className="text-white font-bold text-lg text-center">
                🎄 {daysUntilChristmas} {t('daysBeforeChristmas')} 🎄
              </p>
            </div>

            {/* Nombre de cadeaux */}
              <div className="rounded-lg px-5 py-4 shadow-lg" style={{ backgroundColor: theme.primary }}>
                <h3 className="text-white font-bold text-center text-sm mb-2">{t('giftCount')}</h3>
                <div className="rounded-lg px-5 py-2" style={{ backgroundColor: theme.accent }}>
                  <p className="text-2xl font-bold text-center text-gray-800">{gifts.length}</p>
                </div>
              </div>
            </div>
            </div>

        {/* Add Gift Form */}
        <AddGiftForm
          isOpen={showAddForm}
          onAdd={(data) => createGiftMutation.mutate(data)}
          onCancel={() => setShowAddForm(false)}
          devise={devise}
          theme={theme}
        />

        {/* Toggle Stats Button and Theme Selector */}
        <div className="mb-4 flex flex-col sm:flex-row gap-3">
          <Button
            onClick={() => setShowStats(!showStats)}
            variant="outline"
            className="bg-white hover:bg-gray-100 w-full sm:w-auto"
          >
            {showStats ? <ChevronUp className="w-4 h-4 mr-2" /> : <ChevronDown className="w-4 h-4 mr-2" />}
            {showStats ? t('hide') : t('show')} {t('statistics')}
          </Button>
          <ThemeSelector currentTheme={currentTheme} onThemeChange={setCurrentTheme} />
          <LanguageSelector />
        </div>

        {/* Statistics Section */}
        {showStats && (
          <div className="space-y-4 mb-6">
            {/* Budget boxes in line */}
            <BudgetSection
              budget={budget}
              onUpdate={(data) => updateBudgetMutation.mutate(data)}
              totalDepense={totalDepense}
              totalBudgetise={totalBudgetise}
              theme={theme}
            />

            {/* Chart and Table side by side */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              <div className="h-[350px]">
                <BudgetComparisonChart 
                  totalBudgetise={totalBudgetise}
                  totalDepense={totalDepense}
                  budgetTotal={budgetTotal}
                  devise={devise}
                  theme={theme}
                />
              </div>
              <div className="h-[350px]">
                <CategoryTable gifts={gifts} devise={devise} theme={theme} />
              </div>
            </div>

            {/* Stats Cards in line */}
            <StatsCards gifts={gifts} theme={theme} />
          </div>
        )}

        {/* Gift Table */}
        <div className="mb-8">
          <GiftTable
            gifts={gifts}
            onUpdate={(id, data) => updateGiftMutation.mutate({ id, data })}
            onDelete={(id) => deleteGiftMutation.mutate(id)}
            onAdd={() => setShowAddForm(true)}
            devise={devise}
            theme={theme}
          />
        </div>
      </div>
    </div>
  );
}

export default function NoelTracker() {
  return (
    <LanguageProvider>
      <NoelTrackerContent />
    </LanguageProvider>
  );
}